// Quiz system for VLSI Hero
class VLSIQuiz {
    constructor() {
        this.currentQuestion = 0;
        this.score = 0;
        this.timeLimit = 45 * 60; // 45 minutes in seconds
        this.timeRemaining = this.timeLimit;
        this.timer = null;
        this.userAnswers = [];
        this.achievements = [];
        
        this.questions = [
            {
                id: 1,
                question: "What does VLSI stand for?",
                options: [
                    "Very Large Scale Integration",
                    "Virtual Logic System Integration",
                    "Variable Logic Scale Interface",
                    "Very Low Signal Integration"
                ],
                correct: 0,
                explanation: "VLSI stands for Very Large Scale Integration, which refers to the process of creating integrated circuits by combining millions of transistors into a single chip."
            },
            {
                id: 2,
                question: "Which type of transistor conducts when the gate voltage is HIGH?",
                options: [
                    "PMOS",
                    "NMOS",
                    "Both PMOS and NMOS",
                    "Neither PMOS nor NMOS"
                ],
                correct: 1,
                explanation: "NMOS (N-channel Metal-Oxide-Semiconductor) transistors conduct when the gate voltage is HIGH, making them ideal for pull-down networks in digital circuits."
            },
            {
                id: 3,
                question: "What is the primary advantage of CMOS technology?",
                options: [
                    "High speed operation",
                    "Low power consumption",
                    "High noise immunity",
                    "All of the above"
                ],
                correct: 3,
                explanation: "CMOS (Complementary Metal-Oxide-Semiconductor) technology offers all these advantages: high speed, low power consumption, and high noise immunity, making it the dominant technology in modern digital circuits."
            },
            {
                id: 4,
                question: "In a truth table for an AND gate, what is the output when both inputs are 1?",
                options: [
                    "0",
                    "1",
                    "X (don't care)",
                    "Z (high impedance)"
                ],
                correct: 1,
                explanation: "An AND gate outputs 1 only when both inputs are 1. In all other cases (0,0), (0,1), or (1,0), the output is 0."
            },
            {
                id: 5,
                question: "What is setup time in digital circuits?",
                options: [
                    "Time for the circuit to power up",
                    "Time data must be stable before clock edge",
                    "Time for signal propagation",
                    "Time between clock cycles"
                ],
                correct: 1,
                explanation: "Setup time is the minimum time that data must be stable before the active clock edge to ensure proper operation of sequential elements like flip-flops."
            },
            {
                id: 6,
                question: "Which fabrication process step creates the transistor channels?",
                options: [
                    "Oxidation",
                    "Photolithography",
                    "Ion implantation",
                    "Etching"
                ],
                correct: 2,
                explanation: "Ion implantation is used to dope the silicon substrate with impurities to create the source and drain regions of transistors, effectively forming the conductive channels."
            },
            {
                id: 7,
                question: "What is the primary function of a D flip-flop?",
                options: [
                    "To invert the input signal",
                    "To store a single bit of data",
                    "To perform logical AND operation",
                    "To generate clock signals"
                ],
                correct: 1,
                explanation: "A D flip-flop (Data flip-flop) is a sequential logic element that stores a single bit of data and outputs it on the next clock edge."
            },
            {
                id: 8,
                question: "In Moore's Law, what approximately doubles every two years?",
                options: [
                    "Circuit speed",
                    "Power consumption",
                    "Transistor density",
                    "Chip size"
                ],
                correct: 2,
                explanation: "Moore's Law states that the number of transistors on a microchip doubles approximately every two years, while the cost is halved."
            },
            {
                id: 9,
                question: "What is the output of an XOR gate when both inputs are the same?",
                options: [
                    "0",
                    "1",
                    "Input A",
                    "Input B"
                ],
                correct: 0,
                explanation: "An XOR (Exclusive OR) gate outputs 0 when both inputs are the same (both 0 or both 1), and outputs 1 when the inputs are different."
            },
            {
                id: 10,
                question: "What is the primary cause of power consumption in CMOS circuits?",
                options: [
                    "Leakage current",
                    "Switching activity",
                    "Short-circuit current",
                    "All of the above"
                ],
                correct: 3,
                explanation: "Power consumption in CMOS circuits comes from multiple sources: dynamic power from switching activity, static power from leakage currents, and short-circuit power during transitions."
            }
        ];
        
        this.init();
    }
    
    init() {
        this.bindEvents();
        this.loadProgress();
    }
    
    bindEvents() {
        const startBtn = document.getElementById('start-quiz');
        const nextBtn = document.getElementById('next-question');
        const prevBtn = document.getElementById('prev-question');
        const reviewBtn = document.getElementById('review-answers');
        const retakeBtn = document.getElementById('retake-quiz');
        
        if (startBtn) {
            startBtn.addEventListener('click', () => this.startQuiz());
        }
        
        if (nextBtn) {
            nextBtn.addEventListener('click', () => this.nextQuestion());
        }
        
        if (prevBtn) {
            prevBtn.addEventListener('click', () => this.previousQuestion());
        }
        
        if (reviewBtn) {
            reviewBtn.addEventListener('click', () => this.reviewAnswers());
        }
        
        if (retakeBtn) {
            retakeBtn.addEventListener('click', () => this.retakeQuiz());
        }
    }
    
    startQuiz() {
        document.getElementById('quiz-start').classList.add('hidden');
        document.getElementById('quiz-content').classList.remove('hidden');
        
        this.currentQuestion = 0;
        this.score = 0;
        this.timeRemaining = this.timeLimit;
        this.userAnswers = [];
        
        this.startTimer();
        this.displayQuestion();
        this.updateProgress();
    }
    
    startTimer() {
        this.timer = setInterval(() => {
            this.timeRemaining--;
            this.updateTimerDisplay();
            
            if (this.timeRemaining <= 0) {
                this.finishQuiz();
            }
        }, 1000);
    }
    
    updateTimerDisplay() {
        const minutes = Math.floor(this.timeRemaining / 60);
        const seconds = this.timeRemaining % 60;
        const timerDisplay = document.getElementById('time-remaining');
        
        if (timerDisplay) {
            timerDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
    }
    
    displayQuestion() {
        const question = this.questions[this.currentQuestion];
        const questionText = document.getElementById('question-text');
        const answerOptions = document.getElementById('answer-options');
        const currentQuestionDisplay = document.getElementById('current-question');
        
        if (questionText) {
            questionText.textContent = question.question;
        }
        
        if (currentQuestionDisplay) {
            currentQuestionDisplay.textContent = this.currentQuestion + 1;
        }
        
        if (answerOptions) {
            answerOptions.innerHTML = '';
            
            question.options.forEach((option, index) => {
                const button = document.createElement('button');
                button.className = 'quiz-option w-full text-left p-4 bg-primary/30 rounded-lg hover:bg-primary/50 transition-colors';
                button.textContent = `${String.fromCharCode(65 + index)}) ${option}`;
                button.onclick = () => this.selectAnswer(index);
                
                // Highlight if previously selected
                if (this.userAnswers[this.currentQuestion] === index) {
                    button.classList.add('bg-accent/20', 'border', 'border-accent/40');
                }
                
                answerOptions.appendChild(button);
            });
        }
        
        this.updateNavigationButtons();
        this.updateQuestionDots();
    }
    
    selectAnswer(answerIndex) {
        this.userAnswers[this.currentQuestion] = answerIndex;
        
        // Update button appearance
        const options = document.querySelectorAll('.quiz-option');
        options.forEach((option, index) => {
            option.classList.remove('bg-accent/20', 'border', 'border-accent/40');
            if (index === answerIndex) {
                option.classList.add('bg-accent/20', 'border', 'border-accent/40');
            }
        });
        
        // Show explanation
        this.showExplanation();
        
        // Enable next button
        const nextBtn = document.getElementById('next-question');
        if (nextBtn) {
            nextBtn.disabled = false;
        }
        
        // Auto-advance after 2 seconds
        setTimeout(() => {
            if (this.currentQuestion < this.questions.length - 1) {
                this.nextQuestion();
            }
        }, 2000);
    }
    
    showExplanation() {
        const explanation = document.getElementById('explanation');
        const explanationText = document.getElementById('explanation-text');
        const question = this.questions[this.currentQuestion];
        
        if (explanation && explanationText) {
            explanationText.textContent = question.explanation;
            explanation.classList.remove('hidden');
        }
    }
    
    nextQuestion() {
        if (this.currentQuestion < this.questions.length - 1) {
            this.currentQuestion++;
            this.displayQuestion();
            this.updateProgress();
            this.hideExplanation();
        } else {
            this.finishQuiz();
        }
    }
    
    previousQuestion() {
        if (this.currentQuestion > 0) {
            this.currentQuestion--;
            this.displayQuestion();
            this.updateProgress();
            this.hideExplanation();
        }
    }
    
    hideExplanation() {
        const explanation = document.getElementById('explanation');
        if (explanation) {
            explanation.classList.add('hidden');
        }
    }
    
    updateNavigationButtons() {
        const prevBtn = document.getElementById('prev-question');
        const nextBtn = document.getElementById('next-question');
        
        if (prevBtn) {
            prevBtn.disabled = this.currentQuestion === 0;
        }
        
        if (nextBtn) {
            nextBtn.disabled = this.userAnswers[this.currentQuestion] === undefined;
            nextBtn.textContent = this.currentQuestion === this.questions.length - 1 ? 'Finish' : 'Next';
        }
    }
    
    updateProgress() {
        const progress = ((this.currentQuestion + 1) / this.questions.length) * 100;
        const progressBar = document.getElementById('progress-bar');
        
        if (progressBar) {
            progressBar.style.width = `${progress}%`;
        }
    }
    
    updateQuestionDots() {
        const dotsContainer = document.getElementById('question-dots');
        
        if (dotsContainer) {
            dotsContainer.innerHTML = '';
            
            this.questions.forEach((_, index) => {
                const dot = document.createElement('div');
                dot.className = 'w-3 h-3 rounded-full';
                
                if (index === this.currentQuestion) {
                    dot.classList.add('bg-accent');
                } else if (this.userAnswers[index] !== undefined) {
                    dot.classList.add('bg-accent/60');
                } else {
                    dot.classList.add('bg-gray-600');
                }
                
                dotsContainer.appendChild(dot);
            });
        }
    }
    
    finishQuiz() {
        clearInterval(this.timer);
        
        // Calculate score
        this.score = this.userAnswers.reduce((score, answer, index) => {
            return score + (answer === this.questions[index].correct ? 1 : 0);
        }, 0);
        
        // Calculate time taken
        const timeTaken = this.timeLimit - this.timeRemaining;
        const correctAnswers = this.userAnswers.filter((answer, index) => {
            return answer === this.questions[index].correct;
        }).length;
        
        // Submit quiz results to database
        fetch('/api/quiz/submit', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                quiz_id: 'vlsi_fundamentals',
                quiz_name: 'VLSI Fundamentals Quiz',
                score: this.score,
                total_questions: this.questions.length,
                correct_answers: correctAnswers,
                time_taken: timeTaken,
                answers: this.userAnswers
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.leveled_up) {
                this.showLevelUpNotification();
            }
            if (data.achievements_earned && data.achievements_earned.length > 0) {
                this.displayAchievements(data.achievements_earned);
            }
            
            // Update progress tracker if available
            if (window.progressTracker) {
                window.progressTracker.userProgress = { 
                    ...window.progressTracker.userProgress, 
                    ...data.progress 
                };
                window.progressTracker.updateDisplays();
            }
        })
        .catch(error => {
            console.error('Error submitting quiz:', error);
            // Fallback to local tracking
            if (window.progressTracker) {
                window.progressTracker.takeQuiz(this.score);
            }
        });
        
        // Show results
        this.showResults(timeTaken);
        
        // Save progress
        this.saveProgress();
        
        // Check for achievements
        this.checkAchievements();
    }
    
    showLevelUpNotification() {
        if (window.VLSIHero && window.VLSIHero.notifications) {
            window.VLSIHero.notifications.success('Congratulations! You leveled up!');
        } else {
            alert('Congratulations! You leveled up!');
        }
    }
    
    showResults(timeTaken) {
        document.getElementById('quiz-content').classList.add('hidden');
        document.getElementById('quiz-results').classList.remove('hidden');
        
        const finalScore = document.getElementById('final-score');
        const correctAnswers = document.getElementById('correct-answers');
        const timeDisplay = document.getElementById('time-taken');
        const performanceMessage = document.getElementById('performance-message');
        
        if (finalScore) {
            finalScore.textContent = Math.round((this.score / this.questions.length) * 100);
        }
        
        if (correctAnswers) {
            correctAnswers.textContent = `${this.score}/${this.questions.length}`;
        }
        
        if (timeDisplay) {
            const minutes = Math.floor(timeTaken / 60);
            const seconds = timeTaken % 60;
            timeDisplay.textContent = `${minutes.toString().padStart(2, '0')}:${seconds.toString().padStart(2, '0')}`;
        }
        
        if (performanceMessage) {
            const percentage = (this.score / this.questions.length) * 100;
            let message = '';
            
            if (percentage >= 90) {
                message = 'Excellent! You\'ve mastered VLSI concepts!';
            } else if (percentage >= 80) {
                message = 'Great job! You have a solid understanding.';
            } else if (percentage >= 70) {
                message = 'Good work! Review the topics you missed.';
            } else if (percentage >= 60) {
                message = 'Keep studying! You\'re making progress.';
            } else {
                message = 'More practice needed. Don\'t give up!';
            }
            
            performanceMessage.textContent = message;
        }
        
        // Show earned achievements
        this.displayAchievements();
    }
    
    checkAchievements() {
        const percentage = (this.score / this.questions.length) * 100;
        const timeTaken = this.timeLimit - this.timeRemaining;
        
        // Perfect score achievement
        if (percentage === 100) {
            this.achievements.push({
                id: 'perfect_score',
                name: 'Perfect Score',
                description: 'Answered all questions correctly',
                icon: 'fa-star'
            });
        }
        
        // Speed demon achievement
        if (timeTaken < 300) { // Less than 5 minutes
            this.achievements.push({
                id: 'speed_demon',
                name: 'Speed Demon',
                description: 'Completed quiz in under 5 minutes',
                icon: 'fa-lightning-bolt'
            });
        }
        
        // Knowledge master achievement
        if (percentage >= 90) {
            this.achievements.push({
                id: 'knowledge_master',
                name: 'Knowledge Master',
                description: 'Scored 90% or higher',
                icon: 'fa-graduation-cap'
            });
        }
        
        // First attempt achievement
        if (!this.hasAttemptedBefore()) {
            this.achievements.push({
                id: 'first_attempt',
                name: 'First Attempt',
                description: 'Completed your first quiz',
                icon: 'fa-play'
            });
        }
    }
    
    displayAchievements() {
        const achievementsContainer = document.getElementById('achievements-earned');
        
        if (achievementsContainer && this.achievements.length > 0) {
            achievementsContainer.innerHTML = '';
            
            this.achievements.forEach(achievement => {
                const badge = document.createElement('div');
                badge.className = 'achievement-badge';
                badge.innerHTML = `
                    <i class="fas ${achievement.icon} text-accent text-xl"></i>
                    <div class="text-xs mt-1">${achievement.name}</div>
                `;
                badge.title = achievement.description;
                
                achievementsContainer.appendChild(badge);
            });
        }
    }
    
    reviewAnswers() {
        document.getElementById('quiz-results').classList.add('hidden');
        document.getElementById('quiz-content').classList.remove('hidden');
        
        this.currentQuestion = 0;
        this.displayQuestionReview();
    }
    
    displayQuestionReview() {
        const question = this.questions[this.currentQuestion];
        const questionText = document.getElementById('question-text');
        const answerOptions = document.getElementById('answer-options');
        
        if (questionText) {
            questionText.textContent = question.question;
        }
        
        if (answerOptions) {
            answerOptions.innerHTML = '';
            
            question.options.forEach((option, index) => {
                const button = document.createElement('button');
                button.className = 'quiz-option w-full text-left p-4 rounded-lg';
                button.textContent = `${String.fromCharCode(65 + index)}) ${option}`;
                button.disabled = true;
                
                // Color code the answers
                if (index === question.correct) {
                    button.classList.add('correct');
                } else if (index === this.userAnswers[this.currentQuestion]) {
                    button.classList.add('incorrect');
                } else {
                    button.classList.add('bg-primary/30');
                }
                
                answerOptions.appendChild(button);
            });
        }
        
        this.showExplanation();
    }
    
    retakeQuiz() {
        document.getElementById('quiz-results').classList.add('hidden');
        document.getElementById('quiz-start').classList.remove('hidden');
        
        this.currentQuestion = 0;
        this.score = 0;
        this.userAnswers = [];
        this.achievements = [];
        
        clearInterval(this.timer);
    }
    
    saveProgress() {
        const progress = {
            score: this.score,
            totalQuestions: this.questions.length,
            percentage: (this.score / this.questions.length) * 100,
            timeTaken: this.timeLimit - this.timeRemaining,
            date: new Date().toISOString(),
            answers: this.userAnswers
        };
        
        // Save to localStorage
        const previousAttempts = JSON.parse(localStorage.getItem('vlsi_quiz_attempts') || '[]');
        previousAttempts.push(progress);
        localStorage.setItem('vlsi_quiz_attempts', JSON.stringify(previousAttempts));
        
        // Update global progress
        if (window.VLSIHero && window.VLSIHero.gamification) {
            window.VLSIHero.gamification.addXP(this.score * 10);
        }
    }
    
    loadProgress() {
        const attempts = JSON.parse(localStorage.getItem('vlsi_quiz_attempts') || '[]');
        return attempts;
    }
    
    hasAttemptedBefore() {
        const attempts = this.loadProgress();
        return attempts.length > 0;
    }
    
    getBestScore() {
        const attempts = this.loadProgress();
        if (attempts.length === 0) return 0;
        
        return Math.max(...attempts.map(attempt => attempt.percentage));
    }
    
    getAverageScore() {
        const attempts = this.loadProgress();
        if (attempts.length === 0) return 0;
        
        const total = attempts.reduce((sum, attempt) => sum + attempt.percentage, 0);
        return total / attempts.length;
    }
}

// Initialize quiz when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const quiz = new VLSIQuiz();
    
    // Export for global access
    window.VLSIQuiz = quiz;
});
