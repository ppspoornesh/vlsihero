// Progress tracking system for VLSI Hero
class ProgressTracker {
    constructor() {
        this.userProgress = {
            level: 1,
            xp: 0,
            modulesCompleted: 0,
            totalModules: 12,
            achievements: [],
            streakDays: 0,
            lastActiveDate: null,
            studyTime: 0, // in minutes
            lessonsCompleted: 0,
            quizzesTaken: 0,
            circuitsBuilt: 0,
            averageScore: 0
        };
        
        this.achievements = {
            'first_steps': {
                id: 'first_steps',
                name: 'First Steps',
                description: 'Started learning',
                icon: 'fa-play',
                condition: () => this.userProgress.lessonsCompleted >= 1
            },
            'scholar': {
                id: 'scholar',
                name: 'Scholar',
                description: 'Completed 5 lessons',
                icon: 'fa-book',
                condition: () => this.userProgress.lessonsCompleted >= 5
            },
            'speed_runner': {
                id: 'speed_runner',
                name: 'Speed Runner',
                description: 'Completed quiz in 5 minutes',
                icon: 'fa-lightning-bolt',
                condition: () => this.checkQuizTime()
            },
            'streak_master': {
                id: 'streak_master',
                name: 'Streak Master',
                description: '7 day learning streak',
                icon: 'fa-fire',
                condition: () => this.userProgress.streakDays >= 7
            },
            'perfect_score': {
                id: 'perfect_score',
                name: 'Perfect Score',
                description: '100% on quiz',
                icon: 'fa-star',
                condition: () => this.userProgress.averageScore >= 100
            },
            'graduate': {
                id: 'graduate',
                name: 'Graduate',
                description: 'Completed module',
                icon: 'fa-graduation-cap',
                condition: () => this.userProgress.modulesCompleted >= 1
            }
        };
        
        this.init();
    }
    
    init() {
        this.loadProgress();
        this.updateStreak();
        this.updateDisplays();
        this.generateCalendar();
        this.initializeChart();
        this.checkAchievements();
    }
    
    loadProgress() {
        // Load from database API
        fetch('/api/progress')
            .then(response => response.json())
            .then(data => {
                this.userProgress = { ...this.userProgress, ...data };
                this.updateDisplays();
            })
            .catch(error => {
                console.error('Error loading progress:', error);
                // Fallback to localStorage
                const saved = localStorage.getItem('vlsi_hero_progress');
                if (saved) {
                    this.userProgress = { ...this.userProgress, ...JSON.parse(saved) };
                }
            });
    }
    
    saveProgress() {
        // Save to database API
        fetch('/api/progress', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'update_study_time',
                minutes: 1 // Track minimal study time
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.progress) {
                this.userProgress = { ...this.userProgress, ...data.progress };
            }
        })
        .catch(error => {
            console.error('Error saving progress:', error);
            // Fallback to localStorage
            localStorage.setItem('vlsi_hero_progress', JSON.stringify(this.userProgress));
        });
    }
    
    updateStreak() {
        const today = new Date().toDateString();
        const lastActive = this.userProgress.lastActiveDate;
        
        if (lastActive) {
            const lastActiveDate = new Date(lastActive);
            const todayDate = new Date(today);
            const daysDiff = Math.floor((todayDate - lastActiveDate) / (1000 * 60 * 60 * 24));
            
            if (daysDiff === 1) {
                // Consecutive day
                this.userProgress.streakDays++;
            } else if (daysDiff > 1) {
                // Streak broken
                this.userProgress.streakDays = 1;
            }
            // If daysDiff === 0, it's the same day, no change
        } else {
            // First time
            this.userProgress.streakDays = 1;
        }
        
        this.userProgress.lastActiveDate = today;
        this.saveProgress();
    }
    
    addXP(amount) {
        this.userProgress.xp += amount;
        this.checkLevelUp();
        this.updateDisplays();
        this.saveProgress();
    }
    
    checkLevelUp() {
        const xpForNextLevel = this.getXPForLevel(this.userProgress.level + 1);
        if (this.userProgress.xp >= xpForNextLevel) {
            this.userProgress.level++;
            this.showLevelUpNotification();
        }
    }
    
    getXPForLevel(level) {
        return level * 1000; // Simple progression: 1000 XP per level
    }
    
    showLevelUpNotification() {
        if (window.VLSIHero && window.VLSIHero.notifications) {
            window.VLSIHero.notifications.success(`Level Up! You are now level ${this.userProgress.level}`);
        }
    }
    
    completeLesson(moduleId = 'unknown', moduleName = 'Unknown Module', lessonId = null, lessonName = null) {
        // Send to database API
        fetch('/api/progress', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'complete_lesson',
                module_id: moduleId,
                module_name: moduleName,
                lesson_id: lessonId,
                lesson_name: lessonName
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.progress) {
                this.userProgress = { ...this.userProgress, ...data.progress };
                this.updateDisplays();
                this.checkAchievements();
            }
        })
        .catch(error => {
            console.error('Error completing lesson:', error);
            // Fallback to local update
            this.userProgress.lessonsCompleted++;
            this.addXP(50);
            this.updateDisplays();
            this.checkAchievements();
        });
    }
    
    completeModule() {
        this.userProgress.modulesCompleted++;
        this.addXP(200);
        this.updateDisplays();
        this.checkAchievements();
    }
    
    takeQuiz(score) {
        this.userProgress.quizzesTaken++;
        this.updateAverageScore(score);
        this.addXP(score * 2);
        this.updateDisplays();
        this.checkAchievements();
    }
    
    buildCircuit() {
        // Send to database API
        fetch('/api/progress', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json',
            },
            body: JSON.stringify({
                action: 'build_circuit'
            })
        })
        .then(response => response.json())
        .then(data => {
            if (data.progress) {
                this.userProgress = { ...this.userProgress, ...data.progress };
                this.updateDisplays();
                this.checkAchievements();
            }
        })
        .catch(error => {
            console.error('Error recording circuit build:', error);
            // Fallback to local update
            this.userProgress.circuitsBuilt++;
            this.addXP(30);
            this.updateDisplays();
            this.checkAchievements();
        });
    }
    
    updateAverageScore(newScore) {
        if (this.userProgress.quizzesTaken === 1) {
            this.userProgress.averageScore = newScore;
        } else {
            const total = this.userProgress.averageScore * (this.userProgress.quizzesTaken - 1) + newScore;
            this.userProgress.averageScore = Math.round(total / this.userProgress.quizzesTaken);
        }
    }
    
    checkQuizTime() {
        // This would be checked from quiz results
        const quizAttempts = JSON.parse(localStorage.getItem('vlsi_quiz_attempts') || '[]');
        return quizAttempts.some(attempt => attempt.timeTaken < 300); // Less than 5 minutes
    }
    
    checkAchievements() {
        Object.values(this.achievements).forEach(achievement => {
            if (!this.userProgress.achievements.includes(achievement.id) && achievement.condition()) {
                this.unlockAchievement(achievement.id);
            }
        });
    }
    
    unlockAchievement(achievementId) {
        this.userProgress.achievements.push(achievementId);
        this.saveProgress();
        
        const achievement = this.achievements[achievementId];
        if (achievement && window.VLSIHero && window.VLSIHero.notifications) {
            window.VLSIHero.notifications.success(`Achievement unlocked: ${achievement.name}!`);
        }
        
        this.updateDisplays();
    }
    
    updateDisplays() {
        this.updateProgressCards();
        this.updateLevelDisplay();
        this.updateModuleProgress();
        this.updateStatistics();
    }
    
    updateProgressCards() {
        const overallProgress = Math.round((this.userProgress.modulesCompleted / this.userProgress.totalModules) * 100);
        
        // Update progress percentage
        const progressElement = document.querySelector('[data-progress="overall"]');
        if (progressElement) {
            progressElement.textContent = `${overallProgress}%`;
        }
        
        // Update modules completed
        const modulesElement = document.querySelector('[data-progress="modules"]');
        if (modulesElement) {
            modulesElement.textContent = `${this.userProgress.modulesCompleted}/${this.userProgress.totalModules}`;
        }
        
        // Update quiz score
        const quizElement = document.querySelector('[data-progress="quiz"]');
        if (quizElement) {
            quizElement.textContent = `${this.userProgress.averageScore}%`;
        }
        
        // Update streak
        const streakElement = document.querySelector('[data-progress="streak"]');
        if (streakElement) {
            streakElement.textContent = `${this.userProgress.streakDays} days`;
        }
    }
    
    updateLevelDisplay() {
        const levelElement = document.querySelector('.level-display');
        const xpElement = document.querySelector('.xp-display');
        const levelProgressBar = document.querySelector('.level-progress-bar');
        
        if (levelElement) {
            levelElement.textContent = this.userProgress.level;
        }
        
        if (xpElement) {
            xpElement.textContent = this.userProgress.xp;
        }
        
        if (levelProgressBar) {
            const currentLevelXP = this.getXPForLevel(this.userProgress.level);
            const nextLevelXP = this.getXPForLevel(this.userProgress.level + 1);
            const progressInLevel = this.userProgress.xp - currentLevelXP;
            const xpNeededForLevel = nextLevelXP - currentLevelXP;
            const progressPercentage = (progressInLevel / xpNeededForLevel) * 100;
            
            levelProgressBar.style.width = `${progressPercentage}%`;
        }
    }
    
    updateModuleProgress() {
        const moduleProgressData = [
            { name: 'VLSI Fundamentals', progress: 100 },
            { name: 'Digital Design', progress: 85 },
            { name: 'Circuit Simulation', progress: 72 },
            { name: 'Memory Design', progress: 45 },
            { name: 'Advanced Topics', progress: 0 }
        ];
        
        moduleProgressData.forEach((module, index) => {
            const progressBar = document.querySelector(`[data-module="${index}"] .progress-bar`);
            const progressText = document.querySelector(`[data-module="${index}"] .progress-text`);
            
            if (progressBar) {
                progressBar.style.width = `${module.progress}%`;
            }
            
            if (progressText) {
                progressText.textContent = `${module.progress}%`;
            }
        });
    }
    
    updateStatistics() {
        const stats = {
            studyTime: this.formatTime(this.userProgress.studyTime),
            lessonsCompleted: this.userProgress.lessonsCompleted,
            quizzesTaken: this.userProgress.quizzesTaken,
            circuitsBuilt: this.userProgress.circuitsBuilt,
            averageScore: this.userProgress.averageScore
        };
        
        Object.entries(stats).forEach(([key, value]) => {
            const element = document.querySelector(`[data-stat="${key}"]`);
            if (element) {
                element.textContent = value;
            }
        });
    }
    
    formatTime(minutes) {
        const hours = Math.floor(minutes / 60);
        const remainingMinutes = minutes % 60;
        return `${hours}h ${remainingMinutes}m`;
    }
    
    generateCalendar() {
        const calendarContainer = document.getElementById('calendar-container');
        if (!calendarContainer) return;
        
        const today = new Date();
        const currentMonth = today.getMonth();
        const currentYear = today.getFullYear();
        
        // Get first day of month and number of days
        const firstDay = new Date(currentYear, currentMonth, 1);
        const lastDay = new Date(currentYear, currentMonth + 1, 0);
        const daysInMonth = lastDay.getDate();
        const startingDayOfWeek = firstDay.getDay();
        
        // Generate calendar days
        calendarContainer.innerHTML = '';
        
        // Add empty cells for days before the first day of the month
        for (let i = 0; i < startingDayOfWeek; i++) {
            const emptyDay = document.createElement('div');
            emptyDay.className = 'calendar-day inactive';
            calendarContainer.appendChild(emptyDay);
        }
        
        // Add days of the month
        for (let day = 1; day <= daysInMonth; day++) {
            const dayElement = document.createElement('div');
            dayElement.className = 'calendar-day';
            dayElement.textContent = day;
            
            const dayDate = new Date(currentYear, currentMonth, day);
            const isToday = dayDate.toDateString() === today.toDateString();
            const hasActivity = this.hasActivityOnDate(dayDate);
            
            if (isToday) {
                dayElement.classList.add('current');
            }
            
            if (hasActivity) {
                dayElement.classList.add('has-activity');
            }
            
            calendarContainer.appendChild(dayElement);
        }
    }
    
    hasActivityOnDate(date) {
        // Check if there was any learning activity on this date
        // This would be based on stored activity data
        const activities = JSON.parse(localStorage.getItem('vlsi_daily_activities') || '[]');
        return activities.some(activity => {
            const activityDate = new Date(activity.date);
            return activityDate.toDateString() === date.toDateString();
        });
    }
    
    initializeChart() {
        const ctx = document.getElementById('progress-chart');
        if (!ctx) return;
        
        // Generate sample data for the last 7 days
        const labels = [];
        const data = [];
        const today = new Date();
        
        for (let i = 6; i >= 0; i--) {
            const date = new Date(today);
            date.setDate(date.getDate() - i);
            labels.push(date.toLocaleDateString('en-US', { weekday: 'short' }));
            
            // Generate realistic progress data
            data.push(Math.floor(Math.random() * 100) + 20);
        }
        
        new Chart(ctx, {
            type: 'line',
            data: {
                labels: labels,
                datasets: [{
                    label: 'Learning Progress',
                    data: data,
                    borderColor: '#00FF88',
                    backgroundColor: 'rgba(0, 255, 136, 0.1)',
                    borderWidth: 2,
                    fill: true,
                    tension: 0.4
                }]
            },
            options: {
                responsive: true,
                maintainAspectRatio: false,
                plugins: {
                    legend: {
                        display: false
                    }
                },
                scales: {
                    y: {
                        beginAtZero: true,
                        max: 100,
                        ticks: {
                            color: '#9ca3af'
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.1)'
                        }
                    },
                    x: {
                        ticks: {
                            color: '#9ca3af'
                        },
                        grid: {
                            color: 'rgba(156, 163, 175, 0.1)'
                        }
                    }
                }
            }
        });
    }
    
    // Public methods for external use
    getProgress() {
        return this.userProgress;
    }
    
    getAchievements() {
        return this.userProgress.achievements.map(id => this.achievements[id]);
    }
    
    getLevelInfo() {
        const currentLevelXP = this.getXPForLevel(this.userProgress.level);
        const nextLevelXP = this.getXPForLevel(this.userProgress.level + 1);
        
        return {
            level: this.userProgress.level,
            currentXP: this.userProgress.xp,
            xpForCurrentLevel: currentLevelXP,
            xpForNextLevel: nextLevelXP,
            xpNeeded: nextLevelXP - this.userProgress.xp,
            progressPercentage: ((this.userProgress.xp - currentLevelXP) / (nextLevelXP - currentLevelXP)) * 100
        };
    }
    
    exportProgress() {
        return {
            userProgress: this.userProgress,
            achievements: this.getAchievements(),
            levelInfo: this.getLevelInfo(),
            exportDate: new Date().toISOString()
        };
    }
    
    importProgress(data) {
        if (data.userProgress) {
            this.userProgress = { ...this.userProgress, ...data.userProgress };
            this.saveProgress();
            this.updateDisplays();
        }
    }
    
    resetProgress() {
        if (confirm('Are you sure you want to reset all progress? This cannot be undone.')) {
            localStorage.removeItem('vlsi_hero_progress');
            localStorage.removeItem('vlsi_daily_activities');
            localStorage.removeItem('vlsi_quiz_attempts');
            
            this.userProgress = {
                level: 1,
                xp: 0,
                modulesCompleted: 0,
                totalModules: 12,
                achievements: [],
                streakDays: 0,
                lastActiveDate: null,
                studyTime: 0,
                lessonsCompleted: 0,
                quizzesTaken: 0,
                circuitsBuilt: 0,
                averageScore: 0
            };
            
            this.updateDisplays();
            
            if (window.VLSIHero && window.VLSIHero.notifications) {
                window.VLSIHero.notifications.info('Progress has been reset');
            }
        }
    }
}

// Initialize progress tracker when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const progressTracker = new ProgressTracker();
    
    // Export for global access
    window.VLSIProgressTracker = progressTracker;
    
    // Add to global VLSIHero object if it exists
    if (window.VLSIHero) {
        window.VLSIHero.progressTracker = progressTracker;
    }
});
