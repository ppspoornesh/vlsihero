// Main JavaScript file for VLSI Hero
document.addEventListener('DOMContentLoaded', function() {
    // Mobile menu toggle
    const mobileMenuButton = document.getElementById('mobile-menu-button');
    const mobileMenu = document.getElementById('mobile-menu');
    
    if (mobileMenuButton && mobileMenu) {
        mobileMenuButton.addEventListener('click', function() {
            mobileMenu.classList.toggle('hidden');
        });
    }
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function (e) {
            e.preventDefault();
            const target = document.querySelector(this.getAttribute('href'));
            if (target) {
                target.scrollIntoView({
                    behavior: 'smooth',
                    block: 'start'
                });
            }
        });
    });
    
    // Progress bar animations
    function animateProgressBars() {
        const progressBars = document.querySelectorAll('.progress-bar');
        progressBars.forEach(bar => {
            const width = bar.style.width;
            bar.style.width = '0%';
            setTimeout(() => {
                bar.style.width = width;
            }, 200);
        });
    }
    
    // Intersection observer for animations
    const observerOptions = {
        threshold: 0.1,
        rootMargin: '0px 0px -50px 0px'
    };
    
    const observer = new IntersectionObserver((entries) => {
        entries.forEach(entry => {
            if (entry.isIntersecting) {
                entry.target.classList.add('animate-fade-in');
                
                // Animate progress bars when they come into view
                if (entry.target.classList.contains('progress-section')) {
                    animateProgressBars();
                }
            }
        });
    }, observerOptions);
    
    // Observe elements for animation
    document.querySelectorAll('.animate-on-scroll').forEach(el => {
        observer.observe(el);
    });
    
    // Circuit animation effect
    function createCircuitAnimation() {
        const circuitLines = document.querySelectorAll('.circuit-line');
        circuitLines.forEach((line, index) => {
            line.style.animationDelay = `${index * 0.5}s`;
        });
    }
    
    // Initialize circuit animations
    createCircuitAnimation();
    
    // Typing effect for hero text
    function typeWriter(element, text, speed = 100) {
        let i = 0;
        element.innerHTML = '';
        
        function type() {
            if (i < text.length) {
                element.innerHTML += text.charAt(i);
                i++;
                setTimeout(type, speed);
            }
        }
        
        type();
    }
    
    // Achievement badge hover effects
    document.querySelectorAll('.achievement-badge').forEach(badge => {
        badge.addEventListener('mouseenter', function() {
            this.style.transform = 'scale(1.1)';
            this.style.boxShadow = '0 0 20px rgba(0, 255, 136, 0.5)';
        });
        
        badge.addEventListener('mouseleave', function() {
            this.style.transform = 'scale(1)';
            this.style.boxShadow = 'none';
        });
    });
    
    // Module card hover effects
    document.querySelectorAll('.module-card').forEach(card => {
        card.addEventListener('mouseenter', function() {
            this.style.transform = 'translateY(-10px)';
            this.style.boxShadow = '0 20px 40px rgba(0, 255, 136, 0.2)';
        });
        
        card.addEventListener('mouseleave', function() {
            this.style.transform = 'translateY(0)';
            this.style.boxShadow = 'none';
        });
    });
    
    // Interactive circuit nodes
    function createInteractiveNodes() {
        const nodes = document.querySelectorAll('.circuit-node');
        nodes.forEach(node => {
            node.addEventListener('click', function() {
                this.classList.toggle('active');
                const pulse = document.createElement('div');
                pulse.className = 'pulse-effect';
                this.appendChild(pulse);
                
                setTimeout(() => {
                    pulse.remove();
                }, 1000);
            });
        });
    }
    
    // Progress tracking
    function updateProgress() {
        const progressElements = document.querySelectorAll('[data-progress]');
        progressElements.forEach(element => {
            const progress = element.dataset.progress;
            const progressBar = element.querySelector('.progress-bar');
            if (progressBar) {
                progressBar.style.width = progress + '%';
            }
        });
    }
    
    // Local storage for user progress
    const userProgress = {
        save: function(key, value) {
            localStorage.setItem(`vlsi_hero_${key}`, JSON.stringify(value));
        },
        
        load: function(key) {
            const value = localStorage.getItem(`vlsi_hero_${key}`);
            return value ? JSON.parse(value) : null;
        },
        
        clear: function() {
            Object.keys(localStorage).forEach(key => {
                if (key.startsWith('vlsi_hero_')) {
                    localStorage.removeItem(key);
                }
            });
        }
    };
    
    // Theme toggle (for future dark/light mode)
    function toggleTheme() {
        document.body.classList.toggle('light-theme');
        const theme = document.body.classList.contains('light-theme') ? 'light' : 'dark';
        userProgress.save('theme', theme);
    }
    
    // Load saved theme
    const savedTheme = userProgress.load('theme');
    if (savedTheme === 'light') {
        document.body.classList.add('light-theme');
    }
    
    // Notification system
    const notifications = {
        show: function(message, type = 'info', duration = 3000) {
            const notification = document.createElement('div');
            notification.className = `notification notification-${type}`;
            notification.innerHTML = `
                <div class="notification-content">
                    <span class="notification-message">${message}</span>
                    <button class="notification-close">&times;</button>
                </div>
            `;
            
            document.body.appendChild(notification);
            
            // Auto remove
            setTimeout(() => {
                notification.remove();
            }, duration);
            
            // Manual close
            notification.querySelector('.notification-close').addEventListener('click', () => {
                notification.remove();
            });
        },
        
        success: function(message) {
            this.show(message, 'success');
        },
        
        error: function(message) {
            this.show(message, 'error');
        },
        
        info: function(message) {
            this.show(message, 'info');
        }
    };
    
    // Gamification elements
    const gamification = {
        xp: 0,
        level: 1,
        achievements: [],
        
        addXP: function(amount) {
            this.xp += amount;
            this.checkLevelUp();
            this.updateDisplay();
            userProgress.save('xp', this.xp);
        },
        
        checkLevelUp: function() {
            const newLevel = Math.floor(this.xp / 1000) + 1;
            if (newLevel > this.level) {
                this.level = newLevel;
                notifications.success(`Level up! You are now level ${this.level}`);
                userProgress.save('level', this.level);
            }
        },
        
        unlockAchievement: function(achievementId) {
            if (!this.achievements.includes(achievementId)) {
                this.achievements.push(achievementId);
                notifications.success('Achievement unlocked!');
                userProgress.save('achievements', this.achievements);
            }
        },
        
        updateDisplay: function() {
            const xpDisplay = document.querySelector('.xp-display');
            const levelDisplay = document.querySelector('.level-display');
            
            if (xpDisplay) xpDisplay.textContent = this.xp;
            if (levelDisplay) levelDisplay.textContent = this.level;
        },
        
        init: function() {
            this.xp = userProgress.load('xp') || 0;
            this.level = userProgress.load('level') || 1;
            this.achievements = userProgress.load('achievements') || [];
            this.updateDisplay();
        }
    };
    
    // Initialize gamification
    gamification.init();
    
    // Export functions for use in other scripts
    window.VLSIHero = {
        userProgress,
        notifications,
        gamification,
        typeWriter,
        updateProgress
    };
});

// CSS for notifications
const notificationStyles = `
    .notification {
        position: fixed;
        top: 20px;
        right: 20px;
        background: rgba(30, 41, 59, 0.95);
        border: 1px solid rgba(0, 255, 136, 0.3);
        border-radius: 8px;
        padding: 16px;
        color: white;
        z-index: 1000;
        max-width: 300px;
        backdrop-filter: blur(10px);
        animation: slideIn 0.3s ease-out;
    }
    
    .notification-success {
        border-color: rgba(16, 185, 129, 0.5);
    }
    
    .notification-error {
        border-color: rgba(239, 68, 68, 0.5);
    }
    
    .notification-content {
        display: flex;
        justify-content: space-between;
        align-items: center;
    }
    
    .notification-close {
        background: none;
        border: none;
        color: white;
        font-size: 18px;
        cursor: pointer;
        padding: 0;
        margin-left: 10px;
    }
    
    @keyframes slideIn {
        from {
            transform: translateX(100%);
            opacity: 0;
        }
        to {
            transform: translateX(0);
            opacity: 1;
        }
    }
`;

// Add notification styles to head
const styleSheet = document.createElement('style');
styleSheet.textContent = notificationStyles;
document.head.appendChild(styleSheet);
