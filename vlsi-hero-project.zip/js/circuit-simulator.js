// Circuit Simulator for VLSI Hero
class CircuitSimulator {
    constructor() {
        this.canvas = null;
        this.ctx = null;
        this.waveformCanvas = null;
        this.waveformCtx = null;
        this.components = [];
        this.connections = [];
        this.isSimulating = false;
        this.simulationTime = 0;
        this.timeStep = 0.001; // 1ms
        this.waveformData = [];
        this.selectedComponent = null;
        this.isDragging = false;
        this.dragOffset = { x: 0, y: 0 };
        this.mode = 'draw';
        this.currentTool = 'wire';
        this.gridSize = 20;
        this.zoom = 1;
        this.pan = { x: 0, y: 0 };
        
        // Circuit analysis values
        this.voltage1 = 5.0;
        this.voltage2 = 0.0;
        this.resistance = 1000; // 1kΩ
        this.current = 0;
        this.power = 0;
        
        this.init();
    }
    
    init() {
        this.setupCanvas();
        this.setupWaveformCanvas();
        this.bindEvents();
        this.setupControls();
        this.startRenderLoop();
    }
    
    setupCanvas() {
        this.canvas = document.getElementById('circuit-canvas');
        if (!this.canvas) return;
        
        this.ctx = this.canvas.getContext('2d');
        this.resizeCanvas();
        
        window.addEventListener('resize', () => this.resizeCanvas());
    }
    
    setupWaveformCanvas() {
        this.waveformCanvas = document.getElementById('waveform-canvas');
        if (!this.waveformCanvas) return;
        
        this.waveformCtx = this.waveformCanvas.getContext('2d');
        this.resizeWaveformCanvas();
        
        window.addEventListener('resize', () => this.resizeWaveformCanvas());
    }
    
    resizeCanvas() {
        if (!this.canvas) return;
        
        const rect = this.canvas.getBoundingClientRect();
        this.canvas.width = rect.width;
        this.canvas.height = rect.height;
        
        this.draw();
    }
    
    resizeWaveformCanvas() {
        if (!this.waveformCanvas) return;
        
        const rect = this.waveformCanvas.getBoundingClientRect();
        this.waveformCanvas.width = rect.width;
        this.waveformCanvas.height = rect.height;
        
        this.drawWaveform();
    }
    
    bindEvents() {
        if (!this.canvas) return;
        
        this.canvas.addEventListener('mousedown', (e) => this.onMouseDown(e));
        this.canvas.addEventListener('mousemove', (e) => this.onMouseMove(e));
        this.canvas.addEventListener('mouseup', (e) => this.onMouseUp(e));
        this.canvas.addEventListener('click', (e) => this.onClick(e));
        this.canvas.addEventListener('wheel', (e) => this.onWheel(e));
        
        document.addEventListener('keydown', (e) => this.onKeyDown(e));
    }
    
    setupControls() {
        // Mode selector
        const modeSelect = document.getElementById('editor-mode');
        if (modeSelect) {
            modeSelect.addEventListener('change', (e) => {
                this.mode = e.target.value;
            });
        }
        
        // Component selector
        const componentSelect = document.getElementById('component-select');
        if (componentSelect) {
            componentSelect.addEventListener('change', (e) => {
                this.currentTool = e.target.value;
            });
        }
        
        // Clear button
        const clearBtn = document.getElementById('clear-circuit');
        if (clearBtn) {
            clearBtn.addEventListener('click', () => this.clearCircuit());
        }
        
        // Simulation controls
        const runBtn = document.getElementById('run-simulation');
        const stopBtn = document.getElementById('stop-simulation');
        
        if (runBtn) {
            runBtn.addEventListener('click', () => this.startSimulation());
        }
        
        if (stopBtn) {
            stopBtn.addEventListener('click', () => this.stopSimulation());
        }
        
        // Voltage controls
        const voltage1Slider = document.getElementById('voltage-1');
        const voltage2Slider = document.getElementById('voltage-2');
        const voltage1Display = document.getElementById('voltage-1-display');
        const voltage2Display = document.getElementById('voltage-2-display');
        
        if (voltage1Slider) {
            voltage1Slider.addEventListener('input', (e) => {
                this.voltage1 = parseFloat(e.target.value);
                if (voltage1Display) {
                    voltage1Display.textContent = this.voltage1.toFixed(1) + 'V';
                }
                this.updateMeasurements();
            });
        }
        
        if (voltage2Slider) {
            voltage2Slider.addEventListener('input', (e) => {
                this.voltage2 = parseFloat(e.target.value);
                if (voltage2Display) {
                    voltage2Display.textContent = this.voltage2.toFixed(1) + 'V';
                }
                this.updateMeasurements();
            });
        }
        
        // Component library
        document.querySelectorAll('.component-item').forEach(item => {
            item.addEventListener('click', () => {
                this.currentTool = item.dataset.component;
                this.mode = 'draw';
                
                // Update selectors
                if (componentSelect) {
                    componentSelect.value = this.currentTool;
                }
                if (modeSelect) {
                    modeSelect.value = this.mode;
                }
            });
        });
        
        // Zoom controls
        const zoomInBtn = document.getElementById('zoom-in');
        const zoomOutBtn = document.getElementById('zoom-out');
        
        if (zoomInBtn) {
            zoomInBtn.addEventListener('click', () => this.zoomIn());
        }
        
        if (zoomOutBtn) {
            zoomOutBtn.addEventListener('click', () => this.zoomOut());
        }
    }
    
    onMouseDown(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left - this.pan.x) / this.zoom;
        const y = (e.clientY - rect.top - this.pan.y) / this.zoom;
        
        if (this.mode === 'draw') {
            this.addComponent(x, y);
        } else if (this.mode === 'connect') {
            this.startConnection(x, y);
        } else if (this.mode === 'erase') {
            this.eraseComponent(x, y);
        }
        
        // Check for component selection
        const component = this.getComponentAt(x, y);
        if (component) {
            this.selectedComponent = component;
            this.isDragging = true;
            this.dragOffset = {
                x: x - component.x,
                y: y - component.y
            };
        }
    }
    
    onMouseMove(e) {
        if (!this.isDragging || !this.selectedComponent) return;
        
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left - this.pan.x) / this.zoom;
        const y = (e.clientY - rect.top - this.pan.y) / this.zoom;
        
        this.selectedComponent.x = x - this.dragOffset.x;
        this.selectedComponent.y = y - this.dragOffset.y;
        
        this.draw();
    }
    
    onMouseUp(e) {
        this.isDragging = false;
        this.selectedComponent = null;
    }
    
    onClick(e) {
        const rect = this.canvas.getBoundingClientRect();
        const x = (e.clientX - rect.left - this.pan.x) / this.zoom;
        const y = (e.clientY - rect.top - this.pan.y) / this.zoom;
        
        // Handle component selection for property editing
        const component = this.getComponentAt(x, y);
        if (component) {
            this.selectComponent(component);
        }
    }
    
    onWheel(e) {
        e.preventDefault();
        
        const rect = this.canvas.getBoundingClientRect();
        const mouseX = e.clientX - rect.left;
        const mouseY = e.clientY - rect.top;
        
        const wheel = e.deltaY < 0 ? 1 : -1;
        const zoomIntensity = 0.1;
        const newZoom = this.zoom + wheel * zoomIntensity;
        
        if (newZoom > 0.1 && newZoom < 5) {
            this.zoom = newZoom;
            this.draw();
        }
    }
    
    onKeyDown(e) {
        if (e.key === 'Delete' || e.key === 'Backspace') {
            this.deleteSelectedComponent();
        }
    }
    
    addComponent(x, y) {
        const component = {
            id: Date.now(),
            type: this.currentTool,
            x: Math.round(x / this.gridSize) * this.gridSize,
            y: Math.round(y / this.gridSize) * this.gridSize,
            width: 40,
            height: 20,
            value: this.getDefaultValue(this.currentTool),
            connections: []
        };
        
        this.components.push(component);
        this.draw();
    }
    
    getDefaultValue(type) {
        switch (type) {
            case 'resistor': return '1kΩ';
            case 'capacitor': return '1µF';
            case 'inductor': return '1mH';
            case 'voltage-source': return '5V';
            default: return '';
        }
    }
    
    getComponentAt(x, y) {
        return this.components.find(comp => {
            return x >= comp.x && x <= comp.x + comp.width &&
                   y >= comp.y && y <= comp.y + comp.height;
        });
    }
    
    selectComponent(component) {
        this.selectedComponent = component;
        this.draw();
    }
    
    deleteSelectedComponent() {
        if (this.selectedComponent) {
            const index = this.components.indexOf(this.selectedComponent);
            if (index > -1) {
                this.components.splice(index, 1);
                this.selectedComponent = null;
                this.draw();
            }
        }
    }
    
    eraseComponent(x, y) {
        const component = this.getComponentAt(x, y);
        if (component) {
            const index = this.components.indexOf(component);
            if (index > -1) {
                this.components.splice(index, 1);
                this.draw();
            }
        }
    }
    
    startConnection(x, y) {
        // Connection logic would go here
        // For now, just highlight potential connection points
        this.draw();
    }
    
    clearCircuit() {
        this.components = [];
        this.connections = [];
        this.selectedComponent = null;
        this.draw();
    }
    
    zoomIn() {
        this.zoom = Math.min(this.zoom * 1.2, 5);
        this.draw();
    }
    
    zoomOut() {
        this.zoom = Math.max(this.zoom / 1.2, 0.1);
        this.draw();
    }
    
    startSimulation() {
        this.isSimulating = true;
        this.simulationTime = 0;
        this.waveformData = [];
        
        // Update UI
        const statusIndicator = document.getElementById('sim-status-indicator');
        const statusText = document.getElementById('sim-status-text');
        
        if (statusIndicator) {
            statusIndicator.className = 'w-3 h-3 bg-accent rounded-full';
        }
        
        if (statusText) {
            statusText.textContent = 'Running';
        }
        
        this.simulationLoop();
    }
    
    stopSimulation() {
        this.isSimulating = false;
        
        // Update UI
        const statusIndicator = document.getElementById('sim-status-indicator');
        const statusText = document.getElementById('sim-status-text');
        
        if (statusIndicator) {
            statusIndicator.className = 'w-3 h-3 bg-gray-500 rounded-full';
        }
        
        if (statusText) {
            statusText.textContent = 'Stopped';
        }
    }
    
    simulationLoop() {
        if (!this.isSimulating) return;
        
        this.simulationTime += this.timeStep;
        
        // Perform circuit analysis
        this.analyzeCircuit();
        
        // Update waveform data
        this.updateWaveformData();
        
        // Update time display
        const timeDisplay = document.getElementById('sim-time');
        if (timeDisplay) {
            timeDisplay.textContent = (this.simulationTime * 1000).toFixed(1) + ' ms';
        }
        
        // Continue simulation
        requestAnimationFrame(() => this.simulationLoop());
    }
    
    analyzeCircuit() {
        // Simple circuit analysis for demonstration
        // In a real simulator, this would be much more complex
        
        const voltageDiff = this.voltage1 - this.voltage2;
        this.current = voltageDiff / this.resistance * 1000; // Convert to mA
        this.power = voltageDiff * this.current; // Power in mW
        
        this.updateMeasurements();
    }
    
    updateMeasurements() {
        const currentDisplay = document.getElementById('current-display');
        const powerDisplay = document.getElementById('power-display');
        const resistanceDisplay = document.getElementById('resistance-display');
        
        if (currentDisplay) {
            currentDisplay.textContent = this.current.toFixed(1) + ' mA';
        }
        
        if (powerDisplay) {
            powerDisplay.textContent = this.power.toFixed(1) + ' mW';
        }
        
        if (resistanceDisplay) {
            resistanceDisplay.textContent = (this.resistance / 1000).toFixed(1) + ' kΩ';
        }
    }
    
    updateWaveformData() {
        // Generate sample waveform data
        const voltage = this.voltage1 * Math.sin(2 * Math.PI * 1000 * this.simulationTime); // 1kHz sine wave
        const current = this.current * Math.sin(2 * Math.PI * 1000 * this.simulationTime);
        
        this.waveformData.push({
            time: this.simulationTime,
            voltage: voltage,
            current: current
        });
        
        // Keep only last 1000 samples
        if (this.waveformData.length > 1000) {
            this.waveformData.shift();
        }
        
        this.drawWaveform();
    }
    
    startRenderLoop() {
        const render = () => {
            this.draw();
            requestAnimationFrame(render);
        };
        render();
    }
    
    draw() {
        if (!this.ctx) return;
        
        const { width, height } = this.canvas;
        
        // Clear canvas
        this.ctx.clearRect(0, 0, width, height);
        
        // Apply zoom and pan
        this.ctx.save();
        this.ctx.scale(this.zoom, this.zoom);
        this.ctx.translate(this.pan.x, this.pan.y);
        
        // Draw grid
        this.drawGrid();
        
        // Draw components
        this.drawComponents();
        
        // Draw connections
        this.drawConnections();
        
        this.ctx.restore();
    }
    
    drawGrid() {
        if (!this.ctx) return;
        
        const { width, height } = this.canvas;
        
        this.ctx.strokeStyle = 'rgba(100, 116, 139, 0.2)';
        this.ctx.lineWidth = 1;
        
        // Vertical lines
        for (let x = 0; x < width / this.zoom; x += this.gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(x, 0);
            this.ctx.lineTo(x, height / this.zoom);
            this.ctx.stroke();
        }
        
        // Horizontal lines
        for (let y = 0; y < height / this.zoom; y += this.gridSize) {
            this.ctx.beginPath();
            this.ctx.moveTo(0, y);
            this.ctx.lineTo(width / this.zoom, y);
            this.ctx.stroke();
        }
    }
    
    drawComponents() {
        if (!this.ctx) return;
        
        this.components.forEach(component => {
            this.drawComponent(component);
        });
    }
    
    drawComponent(component) {
        if (!this.ctx) return;
        
        const { x, y, width, height, type, value } = component;
        
        // Set styles
        this.ctx.fillStyle = component === this.selectedComponent ? 'rgba(0, 255, 136, 0.3)' : 'rgba(30, 41, 59, 0.8)';
        this.ctx.strokeStyle = '#00FF88';
        this.ctx.lineWidth = 2;
        
        // Draw component body
        this.ctx.fillRect(x, y, width, height);
        this.ctx.strokeRect(x, y, width, height);
        
        // Draw component-specific symbols
        this.ctx.fillStyle = '#00FF88';
        this.ctx.font = '12px JetBrains Mono';
        this.ctx.textAlign = 'center';
        this.ctx.textBaseline = 'middle';
        
        switch (type) {
            case 'resistor':
                this.ctx.fillText('R', x + width / 2, y + height / 2);
                break;
            case 'capacitor':
                this.ctx.fillText('C', x + width / 2, y + height / 2);
                break;
            case 'inductor':
                this.ctx.fillText('L', x + width / 2, y + height / 2);
                break;
            case 'voltage-source':
                this.ctx.fillText('V', x + width / 2, y + height / 2);
                break;
            case 'ground':
                this.ctx.fillText('⏚', x + width / 2, y + height / 2);
                break;
            default:
                this.ctx.fillText(type.charAt(0).toUpperCase(), x + width / 2, y + height / 2);
        }
        
        // Draw value label
        if (value) {
            this.ctx.font = '10px Inter';
            this.ctx.fillStyle = '#cbd5e1';
            this.ctx.fillText(value, x + width / 2, y + height + 12);
        }
        
        // Draw connection points
        this.drawConnectionPoints(component);
    }
    
    drawConnectionPoints(component) {
        if (!this.ctx) return;
        
        const { x, y, width, height } = component;
        
        this.ctx.fillStyle = '#00FF88';
        const pointRadius = 3;
        
        // Left connection point
        this.ctx.beginPath();
        this.ctx.arc(x, y + height / 2, pointRadius, 0, 2 * Math.PI);
        this.ctx.fill();
        
        // Right connection point
        this.ctx.beginPath();
        this.ctx.arc(x + width, y + height / 2, pointRadius, 0, 2 * Math.PI);
        this.ctx.fill();
    }
    
    drawConnections() {
        if (!this.ctx) return;
        
        this.connections.forEach(connection => {
            this.drawConnection(connection);
        });
    }
    
    drawConnection(connection) {
        if (!this.ctx) return;
        
        this.ctx.strokeStyle = '#00FF88';
        this.ctx.lineWidth = 2;
        
        this.ctx.beginPath();
        this.ctx.moveTo(connection.from.x, connection.from.y);
        this.ctx.lineTo(connection.to.x, connection.to.y);
        this.ctx.stroke();
    }
    
    drawWaveform() {
        if (!this.waveformCtx || this.waveformData.length === 0) return;
        
        const { width, height } = this.waveformCanvas;
        
        // Clear canvas
        this.waveformCtx.clearRect(0, 0, width, height);
        
        // Draw axes
        this.waveformCtx.strokeStyle = '#4b5563';
        this.waveformCtx.lineWidth = 1;
        
        // X-axis
        this.waveformCtx.beginPath();
        this.waveformCtx.moveTo(0, height / 2);
        this.waveformCtx.lineTo(width, height / 2);
        this.waveformCtx.stroke();
        
        // Y-axis
        this.waveformCtx.beginPath();
        this.waveformCtx.moveTo(50, 0);
        this.waveformCtx.lineTo(50, height);
        this.waveformCtx.stroke();
        
        // Draw waveform
        if (this.waveformData.length > 1) {
            this.waveformCtx.strokeStyle = '#00FF88';
            this.waveformCtx.lineWidth = 2;
            
            this.waveformCtx.beginPath();
            
            this.waveformData.forEach((point, index) => {
                const x = (index / this.waveformData.length) * (width - 50) + 50;
                const y = height / 2 - (point.voltage / 10) * (height / 4);
                
                if (index === 0) {
                    this.waveformCtx.moveTo(x, y);
                } else {
                    this.waveformCtx.lineTo(x, y);
                }
            });
            
            this.waveformCtx.stroke();
        }
        
        // Draw labels
        this.waveformCtx.fillStyle = '#9ca3af';
        this.waveformCtx.font = '12px Inter';
        this.waveformCtx.textAlign = 'center';
        this.waveformCtx.fillText('Time', width / 2, height - 10);
        
        this.waveformCtx.save();
        this.waveformCtx.translate(15, height / 2);
        this.waveformCtx.rotate(-Math.PI / 2);
        this.waveformCtx.fillText('Voltage', 0, 0);
        this.waveformCtx.restore();
    }
}

// Initialize circuit simulator when DOM is loaded
document.addEventListener('DOMContentLoaded', function() {
    const simulator = new CircuitSimulator();
    
    // Export for global access
    window.CircuitSimulator = simulator;
    
    // Add to global VLSIHero object if it exists
    if (window.VLSIHero) {
        window.VLSIHero.circuitSimulator = simulator;
    }
});
